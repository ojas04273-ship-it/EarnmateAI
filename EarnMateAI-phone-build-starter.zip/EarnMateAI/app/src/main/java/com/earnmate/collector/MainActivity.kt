package com.earnmate.collector

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private var gems = 0
    private lateinit var gemLabel: TextView
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 25, 20)
        window.navigationBarColor = Color.rgb(12, 25, 20)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(12, 25, 20))
        }
        fun text(value: String, size: Float, color: Int = Color.WHITE): TextView =
            TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
                setPadding(0, 10, 0, 10)
            }
        fun button(value: String, action: () -> Unit): Button =
            Button(this).apply { text = value; setOnClickListener { action() } }

        page.addView(text("EARNMATE AI", 25f, Color.rgb(100, 230, 155)))
        page.addView(text("GEM COLLECTOR  •  VERSION 1.0", 12f, Color.LTGRAY))
        gemLabel = text("$gems / 25 Gems", 30f, Color.WHITE)
        page.addView(gemLabel)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 25; progress = gems
        }
        page.addView(progress, LinearLayout.LayoutParams(-1, 18))
        page.addView(text("Track Gems you have genuinely earned. Quiz answers are suggestions; confirm them in the earning app.", 14f, Color.LTGRAY))

        page.addView(text("FOUR-DIGIT MATCHER", 18f, Color.rgb(100, 230, 155)))
        val target = EditText(this).apply {
            hint = "Enter displayed 4-digit number"
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine()
        }
        page.addView(target)
        val options = (1..4).map {
            EditText(this).apply {
                hint = "Option $it"
                inputType = InputType.TYPE_CLASS_NUMBER
                setSingleLine()
            }
        }
        options.forEach { page.addView(it) }
        val answer = text("Matching option: —", 18f, Color.WHITE)
        page.addView(button("Find matching option") {
            val t = target.text.toString().trim()
            val vals = options.map { it.text.toString().trim() }
            if (!t.matches(Regex("\\d{4}")) || vals.any { !it.matches(Regex("\\d{4}")) }) {
                answer.text = "Enter one 4-digit target and four 4-digit options."
            } else {
                val index = vals.indexOf(t)
                answer.text = if (index >= 0) "Matching option: ${index + 1} (${t})"
                              else "No exact match found."
            }
        })
        page.addView(answer)

        page.addView(text("GEM TRACKER", 18f, Color.rgb(100, 230, 155)))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(button("+1 earned Gem") { changeGems(1) }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(button("−1") { changeGems(-1) }, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(controls)
        status = text("Keep this counter in sync with the Gems shown in the earning app.", 14f, Color.LTGRAY)
        page.addView(status)
        page.addView(button("Reset counter") {
            gems = 0; updateGems(); status.text = "Counter reset."
        })
        page.addView(text("This starter build does not watch, click, or skip ads. It does not access the earning app or submit offers. Ad viewing and reward verification remain in the original app.", 12f, Color.LTGRAY))

        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun changeGems(delta: Int) {
        gems = (gems + delta).coerceIn(0, 25)
        updateGems()
        status.text = if (gems == 25) "25 Gems reached. Continue with the offer manually."
                     else "$gems Gems recorded."
    }

    private fun updateGems() {
        gemLabel.text = "$gems / 25 Gems"
        progress.progress = gems
    }
}
