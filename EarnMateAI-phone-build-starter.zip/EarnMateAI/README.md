# EarnMate AI — Gem Collector v1.0

A phone-first starter Android app for the EarnMate AI project.

## Current features
- Manual four-digit target and four-option matching helper.
- Manual Gem counter from 0 to 25.
- Progress bar and 25-Gem completion notice.
- Dark emerald interface.

## Build without a computer
1. On your phone, create a GitHub repository named `EarnMateAI`.
2. Upload the contents of this folder to the repository root (not the ZIP itself).
3. Open the repository's **Actions** tab.
4. If prompted, enable GitHub Actions.
5. Run **Build EarnMate AI APK** using **Run workflow**, or push a commit to `main`.
6. Open the completed workflow run and download the `EarnMateAI-debug-apk` artifact.
7. Extract the downloaded artifact ZIP and install `app-debug.apk` on your phone.

## Important limitations
This is a starter build, not a screen-reading or accessibility automation app. It does not interact with advertisements, click answers in the earning app, install advertised apps, or bypass verification. The Gem counter is manually updated to match rewards actually shown in the earning app. OCR and permitted screen assistance can be added in a later version after checking the earning app's terms and Android permission requirements.

## Technical
- Kotlin
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- minSdk 23 / targetSdk 35
